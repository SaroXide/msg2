'use client';

import { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function ChatbotPlaceholder() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="absolute bottom-16 right-0 w-80 bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col h-[400px]"
          >
            <div className="bg-emerald-600 p-4 flex justify-between items-center text-white">
              <div>
                <h3 className="font-semibold">Maple Advisor Chat</h3>
                <p className="text-xs text-emerald-100">We typically reply in minutes</p>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-white hover:text-emerald-100 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-grow p-4 bg-slate-50 flex flex-col">
              <div className="bg-white p-3 rounded-lg rounded-tl-none shadow-sm border border-slate-100 self-start max-w-[85%] mb-4">
                <p className="text-sm text-slate-700">Hi there! 👋 How can we help you find the right insurance today?</p>
              </div>
              <div className="mt-auto text-center text-xs text-slate-400">
                Chatbot integration coming soon.
              </div>
            </div>
            <div className="p-3 bg-white border-t border-slate-100">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Type your message..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-full py-2 px-4 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  disabled
                />
                <button className="absolute right-2 top-1/2 -translate-y-1/2 bg-emerald-600 text-white p-1.5 rounded-full opacity-50 cursor-not-allowed">
                  <svg className="w-3 h-3 rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-emerald-600 hover:bg-emerald-700 text-white p-4 rounded-full shadow-lg transition-transform hover:scale-105 active:scale-95 flex items-center justify-center"
        aria-label="Open chat"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
      </button>
    </div>
  );
}
