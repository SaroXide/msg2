'use client';

import { useState } from 'react';
import { Menu, X, Phone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { usePathname } from 'next/navigation';
import Image from 'next/image';

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const pathname = usePathname();
  const isHome = pathname === '/';

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'About', href: '/about' },
    { name: 'Careers', href: '/careers' },
    { name: 'Contact', href: '/contact' },
  ];

  return (
    <header className="bg-white border-b border-slate-100 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <a href="/" className="flex items-center space-x-2">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <Image
                  src="https://drive.google.com/uc?export=view&id=1EXjr17OlgPhMkH6lh0zZWSHHHbU2n83b"
                  alt="Maple Solutions Logo"
                  fill
                  className="object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="font-bold text-xl text-slate-900 tracking-tight">Maple Solutions</span>
            </a>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-slate-600 hover:text-emerald-600 font-medium transition-colors"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* CTA & Mobile Menu Toggle */}
          <div className="flex items-center space-x-4">
            <a
              href="tel:6476600809"
              className="hidden md:flex items-center text-emerald-600 font-semibold hover:text-emerald-700 transition-colors"
            >
              <Phone className="w-4 h-4 mr-2" />
              (647) 660-0809
            </a>
            <a
              href="/#lead-form"
              className="hidden md:inline-flex bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-full font-medium transition-colors"
            >
              Find Advisor
            </a>
            
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-md text-slate-600 hover:text-slate-900 hover:bg-slate-100 focus:outline-none"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-slate-100 bg-white overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-1">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block px-3 py-4 text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50 rounded-md"
                >
                  {link.name}
                </a>
              ))}
              <div className="mt-6 pt-6 border-t border-slate-100 flex flex-col space-y-4 px-3">
                <a
                  href="tel:6476600809"
                  className="flex items-center justify-center text-emerald-600 font-semibold py-3 border border-emerald-200 rounded-xl"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Call (647) 660-0809
                </a>
                <a
                  href="/#lead-form"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex justify-center bg-emerald-600 text-white px-4 py-3 rounded-xl font-medium"
                >
                  Find My Advisor
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
