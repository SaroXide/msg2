'use client';

import { useState } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, ChevronRight, ArrowLeft, ShieldCheck } from 'lucide-react';

const formSchema = z.object({
  insuranceType: z.string().min(1, 'Please select an insurance type'),
  firstName: z.string().min(2, 'First name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email address'),
  phone: z.string().min(10, 'Please enter a valid phone number'),
  employmentStatus: z.string().min(1, 'Please select your employment status'),
  citizenship: z.string().min(1, 'Please select your citizenship status'),
  cityOrPostal: z.string().min(2, 'Please enter your city or postal code'),
  workedWithAdvisor: z.string().min(1, 'Please select an option'),
});

type FormData = z.infer<typeof formSchema>;

const insuranceOptions = [
  'Life Insurance',
  'Home & Auto Insurance',
  'Health & Disability',
  'Business Insurance',
  'Critical Illness',
  'Investments & Retirement',
  'Other',
];

const employmentOptions = [
  'Employed Full-Time',
  'Employed Part-Time',
  'Self-Employed',
  'Unemployed',
  'Retired',
  'Student',
];

const citizenshipOptions = [
  'Canadian Citizen',
  'Permanent Resident',
  'Work/Study Permit',
  'Other',
];

export default function LeadForm() {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const {
    register,
    handleSubmit,
    trigger,
    setValue,
    control,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      insuranceType: '',
      firstName: '',
      email: '',
      phone: '',
      employmentStatus: '',
      citizenship: '',
      cityOrPostal: '',
      workedWithAdvisor: '',
    },
  });

  const insuranceType = useWatch({ control, name: 'insuranceType' });

  const nextStep = async () => {
    let fieldsToValidate: (keyof FormData)[] = [];
    if (step === 1) fieldsToValidate = ['insuranceType'];
    if (step === 2) fieldsToValidate = ['firstName', 'email', 'phone'];

    const isStepValid = await trigger(fieldsToValidate);
    if (isStepValid) {
      setStep((prev) => prev + 1);
    }
  };

  const prevStep = () => {
    setStep((prev) => prev - 1);
  };

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    console.log('Form submitted:', data);
    setIsSubmitting(false);
    setIsSuccess(true);
  };

  if (isSuccess) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-8 text-center max-w-md mx-auto border border-slate-100">
        <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <h3 className="text-2xl font-bold text-slate-900 mb-2">You&apos;re All Set!</h3>
        <p className="text-slate-600 mb-6">
          Thank you for reaching out. One of our handpicked advisors will contact you shortly.
        </p>
        <button
          onClick={() => {
            setIsSuccess(false);
            setStep(1);
          }}
          className="text-emerald-600 font-medium hover:text-emerald-700"
        >
          Submit another request
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden max-w-xl mx-auto border border-slate-100" id="lead-form">
      {/* Progress Bar */}
      <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-5 h-5 text-emerald-600" />
          <span className="font-semibold text-slate-900 text-sm">Find Your Advisor</span>
        </div>
        <div className="flex items-center space-x-1 text-xs font-medium text-slate-500">
          <span className={step >= 1 ? 'text-emerald-600' : ''}>1</span>
          <span className="w-4 h-[2px] bg-slate-200 rounded-full overflow-hidden">
            <div className={`h-full bg-emerald-500 transition-all duration-300 ${step >= 2 ? 'w-full' : 'w-0'}`} />
          </span>
          <span className={step >= 2 ? 'text-emerald-600' : ''}>2</span>
          <span className="w-4 h-[2px] bg-slate-200 rounded-full overflow-hidden">
            <div className={`h-full bg-emerald-500 transition-all duration-300 ${step >= 3 ? 'w-full' : 'w-0'}`} />
          </span>
          <span className={step >= 3 ? 'text-emerald-600' : ''}>3</span>
        </div>
      </div>

      <div className="p-6 sm:p-8">
        <form onSubmit={handleSubmit(onSubmit)}>
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold text-slate-900 mb-2">What type of insurance are you looking for?</h2>
                <p className="text-slate-500 mb-6">Select the main service you need help with today.</p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {insuranceOptions.map((option) => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => {
                        setValue('insuranceType', option, { shouldValidate: true });
                        nextStep();
                      }}
                      className={`p-4 rounded-xl border-2 text-left transition-all ${
                        insuranceType === option
                          ? 'border-emerald-500 bg-emerald-50 text-emerald-900'
                          : 'border-slate-200 hover:border-emerald-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <span className="font-medium">{option}</span>
                    </button>
                  ))}
                </div>
                {errors.insuranceType && (
                  <p className="text-red-500 text-sm mt-3">{errors.insuranceType.message}</p>
                )}
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-5"
              >
                <div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-2">Let&apos;s get to know you</h2>
                  <p className="text-slate-500 mb-6">Where should we send your advisor match?</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">First Name</label>
                  <input
                    {...register('firstName')}
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    placeholder="e.g. Jane"
                  />
                  {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName.message}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                  <input
                    {...register('email')}
                    type="email"
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    placeholder="jane@example.com"
                  />
                  {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                  <input
                    {...register('phone')}
                    type="tel"
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    placeholder="(647) 660-0809"
                  />
                  {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p>}
                </div>

                <div className="pt-4 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={prevStep}
                    className="flex items-center text-slate-500 hover:text-slate-800 font-medium transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4 mr-1" /> Back
                  </button>
                  <button
                    type="button"
                    onClick={nextStep}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl font-medium flex items-center transition-colors"
                  >
                    Continue <ChevronRight className="w-4 h-4 ml-1" />
                  </button>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-5"
              >
                <div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-2">Final details</h2>
                  <p className="text-slate-500 mb-6">This helps us find the perfect advisor for your situation.</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Employment Status</label>
                  <select
                    {...register('employmentStatus')}
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all bg-white"
                  >
                    <option value="">Select status...</option>
                    {employmentOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                  {errors.employmentStatus && <p className="text-red-500 text-sm mt-1">{errors.employmentStatus.message}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Citizenship Status</label>
                  <select
                    {...register('citizenship')}
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all bg-white"
                  >
                    <option value="">Select status...</option>
                    {citizenshipOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                  {errors.citizenship && <p className="text-red-500 text-sm mt-1">{errors.citizenship.message}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">City or Postal Code</label>
                  <input
                    {...register('cityOrPostal')}
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    placeholder="e.g. Toronto or M5V 2H1"
                  />
                  {errors.cityOrPostal && <p className="text-red-500 text-sm mt-1">{errors.cityOrPostal.message}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Have you worked with an advisor before?</label>
                  <div className="flex space-x-4">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="radio" value="Yes" {...register('workedWithAdvisor')} className="w-4 h-4 text-emerald-600 focus:ring-emerald-500" />
                      <span className="text-slate-700">Yes</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input type="radio" value="No" {...register('workedWithAdvisor')} className="w-4 h-4 text-emerald-600 focus:ring-emerald-500" />
                      <span className="text-slate-700">No</span>
                    </label>
                  </div>
                  {errors.workedWithAdvisor && <p className="text-red-500 text-sm mt-1">{errors.workedWithAdvisor.message}</p>}
                </div>

                <div className="pt-4 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={prevStep}
                    className="flex items-center text-slate-500 hover:text-slate-800 font-medium transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4 mr-1" /> Back
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 rounded-xl font-medium flex items-center transition-colors disabled:opacity-70"
                  >
                    {isSubmitting ? 'Submitting...' : 'Submit'}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </form>
      </div>
    </div>
  );
}
