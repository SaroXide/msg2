import React from 'react';
import Image from 'next/image';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300 py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className="relative w-8 h-8 flex items-center justify-center">
                <Image
                  src="https://drive.google.com/uc?export=view&id=1EXjr17OlgPhMkH6lh0zZWSHHHbU2n83b"
                  alt="Maple Solutions Logo"
                  fill
                  className="object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="font-bold text-xl text-white tracking-tight">Maple Solutions Group</span>
            </div>
            <p className="text-slate-400 max-w-sm mb-6">
              Licensed insurance advisors helping Canadians find coverage that fits their needs, goals, and budget.
            </p>
            <p className="text-sm text-slate-500">
              Servicing all over Ontario, Canada.
            </p>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="/" className="hover:text-emerald-400 transition-colors">Home</a></li>
              <li><a href="/about" className="hover:text-emerald-400 transition-colors">About Us</a></li>
              <li><a href="/careers" className="hover:text-emerald-400 transition-colors">Careers</a></li>
              <li><a href="/contact" className="hover:text-emerald-400 transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Contact</h4>
            <ul className="space-y-3">
              <li>
                <a href="tel:6476600809" className="hover:text-emerald-400 transition-colors">
                  (647) 660-0809
                </a>
              </li>
              <li>
                <a href="mailto:info@maplesolutionsgroup.ca" className="hover:text-emerald-400 transition-colors">
                  info@maplesolutionsgroup.ca
                </a>
              </li>
              <li className="pt-4">
                <a href="/privacy" className="hover:text-emerald-400 transition-colors">
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-slate-500">
            &copy; {new Date().getFullYear()} Maple Solutions Group. All rights reserved.
          </p>
          <p className="text-sm text-slate-500 mt-4 md:mt-0">
            We work with 40+ leading insurance providers.
          </p>
        </div>
      </div>
    </footer>
  );
}
