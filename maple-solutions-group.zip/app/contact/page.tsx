import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Phone, Mail, MessageCircle } from 'lucide-react';

export default function Contact() {
  return (
    <>
      <Header />
      <main className="bg-white min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6">Contact Us</h1>
            <p className="text-xl text-slate-600">
              We&apos;re here to help. Reach out to us with any questions or concerns.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="bg-slate-50 rounded-2xl p-8 border border-slate-100 text-center hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Phone className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Call Us</h3>
              <p className="text-slate-600 mb-4">We&apos;re here to help.</p>
              <a href="tel:6476600809" className="text-emerald-600 font-semibold hover:text-emerald-700">
                (647) 660-0809
              </a>
            </div>

            <div className="bg-slate-50 rounded-2xl p-8 border border-slate-100 text-center hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Mail className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Email Us</h3>
              <p className="text-slate-600 mb-4">We&apos;ll respond within 24 hours.</p>
              <a href="mailto:info@maplesolutionsgroup.ca" className="text-emerald-600 font-semibold hover:text-emerald-700">
                info@maplesolutionsgroup.ca
              </a>
            </div>

            <div className="bg-slate-50 rounded-2xl p-8 border border-slate-100 text-center hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <MessageCircle className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Chat</h3>
              <p className="text-slate-600 mb-4">There is an option to chat on the side of the screen.</p>
              <span className="text-emerald-600 font-semibold">
                Chat with us
              </span>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
