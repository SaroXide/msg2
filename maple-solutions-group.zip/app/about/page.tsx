import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Image from 'next/image';

export default function About() {
  return (
    <>
      <Header />
      <main className="bg-white min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6">About Maple Solutions Group</h1>
            <p className="text-xl text-slate-600">
              At Maple Solutions Group, we believe insurance should be simple, clear, and tailored to your life.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
            <div className="relative h-[500px] rounded-3xl overflow-hidden shadow-xl">
              <Image
                src="https://drive.google.com/uc?export=view&id=1HjN2JVRWweGdGngZST-PWcZiSdMmSCN3"
                alt="Our Team"
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="space-y-6">
              <p className="text-lg text-slate-600 leading-relaxed">
                We are a small team based in Toronto, Ontario, with one mission: to provide Canadians with licensed insurance advisors who offer personalized guidance and coverage that fits their needs and budget.
              </p>
              <p className="text-lg text-slate-600 leading-relaxed">
                Our licensed advisors help you protect your loved ones, secure your health, and plan for the future. All without confusing products, pushy sales, or one-size-fits-all solutions. We take the time to understand your goals and recommend coverage from more than 40 trusted providers to ensure you get the right solution.
              </p>
              <p className="text-lg text-slate-600 leading-relaxed">
                When you connect with us, you’re speaking directly to a licensed advisor who listens, explains your options in plain language, and helps you make confident decisions. Many of our advisors are multilingual, including Farsi speakers, so language is never a barrier to understanding your coverage.
              </p>
              <p className="text-lg text-slate-600 leading-relaxed">
                We work with top providers across Canada, including Manulife, IA Financial Group, Equitable Life of Canada, Empire Life, Foresters, Ivari, Beneva, and more. This access allows our advisors to select the policies that offer the best value and fit for each client.
              </p>
              <p className="text-lg text-slate-600 leading-relaxed">
                At Maple Solutions Group, our goal is simple: clear advice, honest guidance, and coverage that works for you. We’re proud to help Canadians feel secure about their insurance so they can focus on what matters most: living their lives with confidence.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
